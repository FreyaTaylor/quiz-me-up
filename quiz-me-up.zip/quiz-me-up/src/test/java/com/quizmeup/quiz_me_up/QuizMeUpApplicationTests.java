package com.quizmeup.quiz_me_up;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizMeUpApplicationTests {

	@Test
	void contextLoads() {
	}

}
