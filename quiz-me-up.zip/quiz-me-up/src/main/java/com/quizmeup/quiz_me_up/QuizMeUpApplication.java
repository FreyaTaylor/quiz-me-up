package com.quizmeup.quiz_me_up;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuizMeUpApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuizMeUpApplication.class, args);
	}

}
